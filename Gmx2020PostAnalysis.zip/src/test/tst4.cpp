#include <itp/core>

int main()
{
	Eigen::Vector3d vec(1, 3, 5);
	std::cout << vec << std::endl;
}